# JuiceShop-Pentest-Project (Generated)

This archive contains the full set of files, commands, and evidence produced during the Juice Shop pentest session.

Folder structure:
- 01_Setup: docker commands and nmap scan output
- 02_XSS: stored XSS payload and Burp request examples
- 03_IDOR: basket JSON outputs demonstrating IDOR
- 04_Security_Misconfig: header outputs and API instructions
- 05_Sensitive_Data_Exposure: JWT token and decoded payload
- 06_Final_Report: Project report (txt and pdf)

How to use:
1. Extract the zip.
2. Review files in each folder.
3. Open Project_Report.pdf for executive summary and findings.

Note:
- Several files contain sensitive tokens. Do not publish them publicly.

Generated on: 2025-12-11
